//
//  ___FILENAME___
//  ___PROJECTNAME___
//
//  Created by ___FULLUSERNAME___ on ___DATE___.
//  Copyright (c) ___YEAR___ AITales IOS Development Team. All rights reserved
//

import UIKit

protocol ___VARIABLE_moduleName___ViewProtocol: AnyObject {
    var viewModel: ___VARIABLE_moduleName___ViewModelProtocol { get }
}

final class ___VARIABLE_moduleName___ViewController: UIViewController {

    // MARK: - IBOutlets
    
    // MARK: - Public Properties
    let viewModel: ___VARIABLE_moduleName___ViewModelProtocol

    // MARK: Constants
    
    // MARK: - Initializers
    init(viewModel: ___VARIABLE_moduleName___ViewModelProtocol) {
        self.viewModel = viewModel
        super.init(nibName: nil, bundle: .main)
    }

    required init?(coder: NSCoder) {
        return nil
    }
    
    // MARK: - Lifecycle
    override func viewDidLoad() {
        super.viewDidLoad()
    }
}

extension ___VARIABLE_moduleName___ViewController: ___VARIABLE_moduleName___ViewProtocol {
    
}
