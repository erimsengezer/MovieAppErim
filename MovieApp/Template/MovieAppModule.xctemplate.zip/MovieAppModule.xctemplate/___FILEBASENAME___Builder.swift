//
//  ___FILENAME___
//  ___PROJECTNAME___
//
//  Created by ___FULLUSERNAME___ on ___DATE___.
//  Copyright (c) ___YEAR___ All rights reserved.
// 

import UIKit

enum ___VARIABLE_moduleName___Builder {
    
    static func generate() -> UIViewController? {
        let repository: ___VARIABLE_moduleName___RepositoryProtocol = ___VARIABLE_moduleName___Repository()
        let viewModel: ___VARIABLE_moduleName___ViewModelProtocol = ___VARIABLE_moduleName___ViewModel(repository: repository)

        let view: ___VARIABLE_moduleName___ViewProtocol = ___VARIABLE_moduleName___ViewController(viewModel: viewModel)
        viewModel.view = view
        
        return view as? UIViewController
    }
}
