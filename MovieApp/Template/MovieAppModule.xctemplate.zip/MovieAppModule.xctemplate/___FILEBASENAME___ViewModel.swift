//
//  ___FILENAME___
//  ___PROJECTNAME___
//
//  Created by ___FULLUSERNAME___ on ___DATE___.
//  Copyright (c) ___YEAR___ AITales IOS Development Team. All rights reserved

import Foundation

protocol ___VARIABLE_moduleName___ViewModelProtocol: AnyObject {
    var view: ___VARIABLE_moduleName___ViewProtocol? { get set }
}

final class ___VARIABLE_moduleName___ViewModel: ___VARIABLE_moduleName___ViewModelProtocol {

    // MARK: Definitions
    private let repository: ___VARIABLE_moduleName___RepositoryProtocol
    weak var view: ___VARIABLE_moduleName___ViewProtocol?
    
    // MARK: Private Props

    // MARK: Public Props

    // MARK: Initiliazer
    required init(repository: ___VARIABLE_moduleName___RepositoryProtocol) {
        self.repository = repository
    }
}

