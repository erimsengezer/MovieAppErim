//
//  ___FILENAME___
//  ___PROJECTNAME___
//
//  Created by ___FULLUSERNAME___ on ___DATE___.
//  Copyright (c) ___YEAR___ All rights reserved.
//

import Foundation

protocol ___VARIABLE_moduleName___RepositoryProtocol: AnyObject {
    
}

final class ___VARIABLE_moduleName___Repository: ___VARIABLE_moduleName___RepositoryProtocol {
    
}
